namespace Models {
public class Adult : Person {
    public Job JobTitle { get; set; }
}
}